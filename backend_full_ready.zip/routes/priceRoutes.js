
import express from "express";
import Price from "../models/Price.js";
const router = express.Router();

router.get("/", async (req,res)=>{
  const p = await Price.findOne();
  res.json(p || { value: 0 });
});

router.post("/", async (req,res)=>{
  const { value } = req.body;
  let p = await Price.findOne();
  if(!p) p = new Price({ value });
  p.value = value;
  p.updatedAt = new Date();
  await p.save();
  res.json(p);
});

export default router;
