
import express from "express";
import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const router = express.Router();

router.post("/login", async (req,res)=>{
  const {username, password} = req.body;
  const user = await User.findOne({ username });

  if(!user) return res.status(400).json({msg:"User not found"});

  const match = await bcrypt.compare(password, user.password);
  if(!match) return res.status(400).json({msg:"Wrong password"});

  const token = jwt.sign({ id:user._id }, "SECRET", { expiresIn:"3d" });
  res.json({ token });
});

export default router;
