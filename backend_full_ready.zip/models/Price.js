
import mongoose from "mongoose";

const PriceSchema = new mongoose.Schema({
  value: Number,
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model("Price", PriceSchema);
